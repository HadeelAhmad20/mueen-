<?php
include 'connect.php';

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];

$checkQuery = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($checkQuery);

if ($result->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "❌ Email already registered"]);
} else {
    $sql = "INSERT INTO users (username, email, password, phone)
            VALUES ('$username', '$email', '$password', '$phone')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["success" => true, "message" => "✅ Signup successful"]);
    } else {
        echo json_encode(["success" => false, "message" => "❌ Signup failed"]);
    }
}

$conn->close();
?>
