<?php
include 'connect.php';

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo json_encode(["success" => true, "message" => "✅ Login successful"]);
} else {
    echo json_encode(["success" => false, "message" => "❌ Invalid email or password"]);
}

$conn->close();
?>

