<?php
include 'connect.php';

$email = $_POST['email'];
$newPassword = $_POST['password'];

// Check if user exists
$sqlCheck = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sqlCheck);

if ($result->num_rows > 0) {
    // Update password
    $sqlUpdate = "UPDATE users SET password = '$newPassword' WHERE email = '$email'";
    if ($conn->query($sqlUpdate) === TRUE) {
        echo json_encode(["success" => true, "message" => "✅ Password updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "❌ Failed to update password"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "❌ Email not found"]);
}

$conn->close();
?>
