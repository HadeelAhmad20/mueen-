<?php
$host = "localhost";
$user = "root";
$password = "mysql"; 
$db = "mueenDBS";

// Connect without specifying database
$conn = new mysqli($host, $user, $password);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $db";
if ($conn->query($sql) === FALSE) {
    die("❌ Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db($db);

// Create 'users' table if it doesn't exist
$table = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100),
    phone VARCHAR(20)
)";
if ($conn->query($table) === FALSE) {
    die("❌ Error creating table: " . $conn->error);
}
?>
